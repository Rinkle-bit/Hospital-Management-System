package hospital.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Employee_info extends JFrame {

    Employee_info(){

        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 990, 590);
        panel.setBackground(new Color(109, 164, 170));
        panel.setLayout(null);
        add(panel);

        JTable table = new JTable();
        table.setBounds(10, 34, 980, 450);
        table.setBackground(new Color(109, 164, 170));
        table.setFont(new Font( "Tahoma",Font.BOLD, 12));
        panel.add(table);

        try {
            conn c = new conn();
            String q = "select * from EMP_INFO";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));

        } catch (Exception e) {
            e.printStackTrace();
        }


        JLabel label1 = new JLabel("ID");
        label1.setBounds(66, 9, 70, 20);
        label1.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(label1);

        JLabel label2 = new JLabel("Name");
        label2.setBounds(136, 9, 70, 20);
        label2.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(label2);

        JLabel label3 = new JLabel("Age");
        label3.setBounds(256, 9, 70, 20);
        label3.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(label3);


        JLabel label4 = new JLabel("Gender");
        label4.setBounds(356, 9, 70, 20);
        label4.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(label4);

        JLabel label5 = new JLabel("Phone Number");
        label5.setBounds(467, 9, 150, 20);
        label5.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(label5);

        JLabel label6 = new JLabel("Salary");
        label6.setBounds(667, 9, 150, 20);
        label6.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(label6);

        JLabel label7 = new JLabel("Gmail");
        label7.setBounds(840, 9, 150, 20);
        label7.setFont(new Font("Tahoma", Font.BOLD, 14));
        panel.add(label7);



        JButton button = new JButton("BACK");
        button.setBounds(350, 500, 120, 30);
        button.setBackground(Color.BLACK);
        button.setForeground(Color.white);

        panel.add(button);

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);

            }
        });

        setUndecorated(true);
        setSize(1000, 600);
        setLocation(350, 230);
        setLayout(null);
        setVisible(true);


    }
    public static void main(String[] args) {
        new Employee_info();

    }
}

package hospital.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Login extends JFrame  implements ActionListener {

    JButton  b1, b2 ;
    JTextField textField;
    JPasswordField PasswordField;

    Login(){

        JLabel nameLabel = new JLabel("Username");
        nameLabel.setBounds(40, 20, 100, 30);
        nameLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
        nameLabel.setForeground(Color.BLACK);
        add(nameLabel);

        JLabel password = new JLabel("Password");
        password.setBounds(40, 70, 100, 30);
        password.setFont(new Font("Tahoma", Font.BOLD, 16));
        password.setForeground(Color.BLACK);
        add(password);

        textField = new JTextField();
        textField.setBounds(150, 20, 150, 30);
        textField.setFont(new Font("Tahoma", Font.PLAIN, 15));
        textField.setBackground(new Color(255, 179, 0));
        add(textField);

        PasswordField = new JPasswordField();
        PasswordField.setBounds(150, 70, 150, 30);
        PasswordField.setFont(new Font("Tahoma", Font.PLAIN, 15));
        PasswordField.setBackground(new Color(255, 179, 0));
        add(PasswordField);

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icon/login.png"));
        Image i1 = imageIcon.getImage().getScaledInstance(500, 500, Image.SCALE_DEFAULT);
        ImageIcon imageIcon1 = new ImageIcon(i1);
        JLabel label = new JLabel(imageIcon1);
        label.setBounds(300, -30, 400, 300);
        add(label);

        b1 = new JButton("Login");
        b1.setBounds(40, 140, 120, 30);
        b1.setFont(new Font("serif", Font.BOLD, 15));
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.white);
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton("Cancel");
        b2.setBounds(180, 140, 120, 30);
        b2.setFont(new Font("serif", Font.BOLD, 15));
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.white);
        b2.addActionListener(this);
        add(b2);


        getContentPane().setBackground(new Color(109, 164, 170));
        setSize( 750, 300);
        setLocation(400,0);
        setLayout(null);
        setVisible(true);

    }
    static void main() {
        new Login();

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == b1){
            try {
                conn c = new conn();
                String user = textField.getText();
                String Pass = PasswordField.getText();
                String q = "select * from login where ID = '"+user+"' and PW = '"+Pass+"'";
                ResultSet resultSet = c.statement.executeQuery(q);
                if (resultSet.next()){
                    new Reception();
                    setVisible(false);
                }else {
                    JOptionPane.showMessageDialog(null,"Invalid");
                }

            }catch (Exception E){
                System.getLogger(NEW_PATIENT.class.getName()).log(System.Logger.Level.ERROR, "Database error", e);
            }

        }else {
            System.exit( 10);


        }
    }
}
